﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string Connection = @"Server=DESKTOP-LQCF567\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
